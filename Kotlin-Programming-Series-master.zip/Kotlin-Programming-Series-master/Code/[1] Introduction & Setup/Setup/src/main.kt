fun main(args: Array<String>)
{
    println("Hello World");
}