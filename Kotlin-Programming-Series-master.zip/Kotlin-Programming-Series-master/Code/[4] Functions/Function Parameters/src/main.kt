fun main(args: Array<String>)
{
    Addition(4, 5);
    Addition(3, 10);
    Addition(33, 4798774);
}

fun Addition(num1: Int, num2: Int)
{
    println(num1 + num2);
}