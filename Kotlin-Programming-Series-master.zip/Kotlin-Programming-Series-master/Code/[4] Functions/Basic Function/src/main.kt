fun main(args: Array<String>)
{
    EpicFunction();
}

fun EpicFunction()
{
    println("Epic Hello");
}