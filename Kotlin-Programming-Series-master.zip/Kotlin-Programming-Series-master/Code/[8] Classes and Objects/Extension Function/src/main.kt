class EpicClass
{
    fun Hello()
    {
        println("Hello World");
    }
}

fun EpicClass.OHYH()
{
    println("Oh yh!!!");
}

fun main(args: Array<String>)
{
    var epic = EpicClass();
    epic.Hello();
    epic.OHYH();
}
