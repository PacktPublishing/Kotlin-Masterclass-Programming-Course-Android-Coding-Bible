fun main(args: Array<String>)
{

}

fun Print()
{
    println("Hello World");
}