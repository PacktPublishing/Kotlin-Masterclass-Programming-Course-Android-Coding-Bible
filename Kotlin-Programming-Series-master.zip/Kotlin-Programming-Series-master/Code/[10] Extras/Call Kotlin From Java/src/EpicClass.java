public class EpicClass
{
    public static void main(String[] args)
    {
        MainKt.Print();
    }
}
