fun main(args: Array<String>)
{
    EpicClass.Print();
    EpicClass.epicVar = 9;

    println(EpicClass.epicVar);
}
