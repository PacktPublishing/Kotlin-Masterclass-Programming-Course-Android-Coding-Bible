public class EpicClass
{
    public static int epicVar;

    public static void Print()
    {
        System.out.println("Hello World");
    }
}
