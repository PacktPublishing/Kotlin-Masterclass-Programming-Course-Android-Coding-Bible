fun main(args: Array<String>)
{
    var epic: Any? = null;
    var str: String? = epic as? String;

    println(str);
}
