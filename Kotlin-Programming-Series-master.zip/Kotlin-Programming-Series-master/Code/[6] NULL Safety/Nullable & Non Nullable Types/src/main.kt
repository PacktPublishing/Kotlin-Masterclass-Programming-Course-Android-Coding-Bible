fun main(args: Array<String>)
{
    var epicVar: Int?;
    epicVar = null;

    if (epicVar == null)
    {
        epicVar = 1;
    }

    println(epicVar);
}
