fun main(args: Array<String>)
{
    print("World");
    print("World");
    print("World");
    println("Hello");
    println("Hello");
    println("Hello");

    var data: Int = Integer.valueOf(readLine());

    println(data * 2);
}