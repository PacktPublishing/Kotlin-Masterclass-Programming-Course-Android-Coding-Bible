fun main(args: Array<String>)
{
    var num1 = 55;
    var num2 = 23;

    /*
        --------------------
        Arithmetic Operators
        --------------------
     */

    // Addition Operator
    println(num1 + num2);

    // Subtraction Operator
    println(num1 - num2);

    // Multiplication Operator
    println(num1 * num2);

    // Division Operator
    println(num1 / num2);
    println(num1.toFloat() / num2.toFloat());

    // Modulus Operator
    println(num1 % num2);
}