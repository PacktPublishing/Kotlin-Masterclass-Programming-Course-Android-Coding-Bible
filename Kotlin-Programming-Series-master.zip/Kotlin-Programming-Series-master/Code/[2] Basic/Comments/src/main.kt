fun main(args: Array<String>)
{
    // Hello World
    var i = 9;

    /*
    Hello
    World
    Aquaman was epic!!!
     */
    var x: Long = i.toLong();

    var epicString:String;
    epicString = x.toString();

    println(epicString);
}