fun main(args: Array<String>)
{
    var num1 = 55;
    var num2 = 55;

    /*
        --------------------
        Relational Operators
        --------------------
     */

    // Equal To
    println(num1 == num2);

    // Not Equal To
    println(num1 != num2);

    // Greater Than
    println(num1 > num2);

    // Less Than
    println(num1 < num2);

    // Greater Than Or Equal To
    println(num1 >= num2);

    // Less Than Or Equal To
    println(num1 <= num2);
}