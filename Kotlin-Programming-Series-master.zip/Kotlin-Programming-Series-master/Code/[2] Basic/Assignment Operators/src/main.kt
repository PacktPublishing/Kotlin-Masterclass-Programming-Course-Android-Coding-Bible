fun main(args: Array<String>)
{
    // Basic Assignment Operator
    var num1 = 55;

    /*
        --------------------
        Assignment Operators
        --------------------
     */

    // Addition Assignment Operator
    num1 += 5; // num1 = num1 + 5;
    println(num1);

    num1 = 55;

    // Subtraction Assignment Operator
    num1 -= 5; // num1 = num1 - 5;
    println(num1);

    num1 = 55;

    // Multiplication Assignment Operator
    num1 *= 5; // num1 = num1 * 5;
    println(num1);

    num1 = 55;

    // Division Assignment Operator
    num1 /= 5; // num1 = num1 / 5;
    println(num1);

    num1 = 57;

    // Modulus Assignment Operator
    num1 %= 5; // num1 = num1 % 5;
    println(num1);
}