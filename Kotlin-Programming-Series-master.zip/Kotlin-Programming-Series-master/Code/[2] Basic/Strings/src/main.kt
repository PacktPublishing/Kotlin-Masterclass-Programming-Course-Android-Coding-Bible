fun main(args: Array<String>)
{
    var epicString = "Hello World";

    println(epicString);
    println(epicString.length);

    println(epicString.get(7));

    println(epicString.compareTo("Hello World"));

    var result = epicString.plus("Frahaan");

    println(result);
}