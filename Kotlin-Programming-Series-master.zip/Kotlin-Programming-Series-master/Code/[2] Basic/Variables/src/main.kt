fun main(args: Array<String>)
{
    var epicVar = "Frahaan";
    var num1 = 5;
    val num2 = 67;

    println(epicVar);
    println(num1);
    println(num2);

    epicVar = "Batman";
    num1 = 100;
    //num2 = 99;

    println(epicVar);
    println(num1);
    println(num2);
}