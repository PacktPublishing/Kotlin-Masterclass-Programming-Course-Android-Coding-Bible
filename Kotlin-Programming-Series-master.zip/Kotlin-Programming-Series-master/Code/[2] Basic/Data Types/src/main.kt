fun main(args: Array<String>)
{
    var epicVar: String = "Frahaan";
    var num1 = 9;
    var num2: Float;

    num2 = 8.0f;

    println(epicVar);
    println(num1);
    println(num2);

}