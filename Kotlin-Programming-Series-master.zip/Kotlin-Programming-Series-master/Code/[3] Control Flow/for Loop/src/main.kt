fun main(args: Array<String>)
{
    var epicArray = arrayOf(1, 2, 3, 4, 5, 6, 7, 8);

    for (item in epicArray)
    {
        //println(item);
    }

    for (i in 1..15)
    {
        //println(i * i);
    }

    for (i in 1..15 step 3)
    {
        println(i);
    }
}